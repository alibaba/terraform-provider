### ESS scaling schedule Example

The example launches ESS schedule task, which will create ECS by the schedule time.

### Get up and running

* Planning phase

		terraform plan 

* Apply phase

		terraform apply 

* Destroy 

		terraform destroy